create database users;
use users;
CREATE TABLE seller(name varchar(200), address varchar(200),phone int,email varchar(200),username varchar(200) primary key,password varchar(200));
CREATE TABLE cars (
    id INT AUTO_INCREMENT PRIMARY KEY,
    seller_id varchar(255),
    make VARCHAR(255),
    picture BLOB,  -- Change the data type to BLOB to store binary data
    price DECIMAL(10, 2),
    description TEXT,
    FOREIGN KEY (seller_id) REFERENCES seller(username)
);