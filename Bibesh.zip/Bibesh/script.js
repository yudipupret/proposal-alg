document.querySelectorAll('input').forEach(input => {
    input.addEventListener('focus', () => {
        input.style.backgroundColor = 'yellow';
    });
    
    input.addEventListener('blur', () => {
        input.style.backgroundColor = 'white';
    });
});

document.querySelectorAll('button').forEach(button => {
    button.addEventListener('mouseover', () => {
        button.style.backgroundColor = 'lightblue';
    });
    
    button.addEventListener('mouseout', () => {
        button.style.backgroundColor = '';
    });
});

const featuredCars = [
    { name: "2022 Toyota Camry", price: "$25,000", image: "car1.jpg" },
    { name: "2023 BMW X5", price: "$50,000", image: "car2.jpg" },
    { name: "2021 Ford Mustang", price: "$35,000", image: "car3.jpg" }
];

function createCarHTML(car) {
    return `
    <div class="car">
        <img src="${car.image}" alt="${car.name}">
        <h3>${car.name}</h3>
        <p>${car.price}</p>
    </div>
    `;
}

function addFeaturedCars() {
    const carListContainer = document.getElementById('carList');
    featuredCars.forEach(car => {
        const carHTML = createCarHTML(car);
        carListContainer.innerHTML += carHTML;
    });
}

window.onload = addFeaturedCars;