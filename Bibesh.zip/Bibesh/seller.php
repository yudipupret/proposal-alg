<!DOCTYPE html>
<html lang="en">
<?php 
        include('globvar.php');
        include("seschk.php");
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="seller.css">
    <title>Seller Page</title>
    <link rel="icon" type="image/png" href="https://img.icons8.com/3d-fluency/188/1FB141/icons8-new-logo.png">
</head>
<body>
    <header>
        <div class="logo">NewEra Dealership</div>
        <nav>
            <ul>
                <li><a href="search.php">Search</a></li>
                <li><a href="add_car.php">Add car</a></li>
                <li><a href="logout.php">Logout</a></li>

            </ul>
        </nav>
    </header>
    <?php
        include("conn.php");
        $query="select * from seller";
                $result=mysqli_query($conn,$query);
                while($row=mysqli_fetch_assoc($result))
                {
                    $userID= $row['username'];
                    $email= $row['email'];
                    $address=$row['address'];
                    $phone=$row['phone'];
                }

    ?>
    <main>
        <h1>Welcome <?php $_SESSION['username']?></h1>
        <section id="seller-info">
            <h2>My Information</h2>
            <div class="seller-details">
                <div class="seller-info">
                    <h3>Name</h3>
                    <p><?php echo($userID);?></p>
                </div>
                <div class="seller-info">
                    <h3>Email:</h3>
                    <p><?php echo($email);?></p>
                </div>
                <div class="seller-info">
                    <h3>Address:</h3>
                    <p><?php echo($address);?></p>
                </div>
                <div class="seller-info">
                    <h3>Phone Number:</h3>
                    <p><?php echo($phone);?></p>
                </div>
            </div>
        </section>
    
        <section id="faqs">
            <h2>Frequently Asked Questions</h2>
            <div class="faq-entry">
                <h3>How do I contact the seller?</h3>
                <p>You can contact the seller through email yudip@neweradealership.com</p>
            </div>
        </section>
    </main>
    <footer>
        <p>Contact us: info@neweradealership.com | Phone: +61-451681548</p>
    </footer>
    
    <script src="script.js"></script>
</body>
</html>
