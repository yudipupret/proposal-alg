<?php
    if(isset($_SESSION['username']))
    { 
        echo("<script>console.log('session verified');</script>");
    }
    elseif(isset($_SESSION['user'])){
        echo("<script>console.log('session verified');</script>");   
    }
    else 
    {
        echo '<script>
            alert("Please Login First");
            window.location.href="login.php";
            </script>';
    }
?>