<?php
    if(isset($_SESSION['username']))
    { 
            header('seller.php');
    }
    
?>