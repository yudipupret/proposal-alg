<HTML>
    <body>
        <?php
            if(isset($_SESSION['username']))
            { 
                include('seller.php');
                
            }
            else 
            {   include('globvar.php');
                include("conn.php");
                $Logged=false;
                $existence=false;
                $e= $_POST["User"];
                $s= $_POST["pass"];
                $query="select * from seller";
                $result=mysqli_query($conn,$query);
                while($row=mysqli_fetch_assoc($result))
                {
                    $userID= $row['username'];
                    $userPSS= $row['password'];
                    if($userID==$e)
                    {
                        if($userPSS==$s)
                        {
                            $Logged=true;
                            $_SESSION['username']=$row['username'];
                        }
                        else
                        {
                            echo '<script>alert("Wrong Password");</script>';
                            $Logged=False;
                        }
                        $existence=true;
                        }
                }
                if($existence==False)
                {
                    echo '<script>alert("User not found")</script>';
                
                }
                
                if($Logged==true)
                {
                    include('seller.php');
                }
                else
                {
                    include("login.php");
                }
            }
            $conn->close();
        ?>
    </body>
</HTML>