<!DOCTYPE html>
<html lang="en">
    <?php 
        include("globvar.php");
        include("_seschk.php");
    ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Login</title>
    <link rel="icon" type="image/png" href="https://img.icons8.com/3d-fluency/188/1FB141/icons8-new-logo.png">
</head>
<body>
    <header>
        <div class="logo">NewEra Dealership</div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="search.php">Search</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="registration.html"><img src="https://img.icons8.com/fluency/48/add-user-male.png" alt="Icon" width="32" height="32" /></a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <h1>Login</h1>
        <form name ="form" method="POST" action="a124au436670_323.php">
            <label for="username">Username:</label>
            <input type="text" name="User" required>
            <label for="username">Password:</label>
            <input type="password" name="pass" required>
            <button type="submit">Login</button>
        </form>
    </main>
    
    <footer>
        <p>Contact us: info@neweradealership.com | Phone: +61-451681548</p>
    </footer>
    
    <script src="script.js"></script>
</body>
</html>
