<?php
// Establish database connection
include('globvar.php');
include('seschk.php');
include('conn.php');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escape user inputs for security
    $make = $conn->real_escape_string($_POST['make']);
    $price = $conn->real_escape_string($_POST['price']);
    $description = $conn->real_escape_string($_POST['description']);

    // Get seller ID from session
    $seller_username = $_SESSION['user']; // Assuming 'user' is the session variable storing seller username

    // Query to retrieve seller ID based on username
    $query = "SELECT username FROM seller WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $seller_username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $seller_id = $row['username'];
    } else {
        // Seller not found, handle error
        echo "<script>alert('Seller not found!');</script>";
        echo "<script>window.location.href = 'add_car.php';</script>"; // Redirect to add_car.php
        exit(); // Exit script
    }

    // File upload handling
    $picture = file_get_contents($_FILES['picture']['tmp_name']); // Read the file into binary data

    // Insert data into database
    $sql = "INSERT INTO cars (seller_id, make, picture, price, description)
            VALUES (?, ?, ?, ?, ?)";

    // Prepare the SQL statement with placeholders
    $stmt = $conn->prepare($sql);

    // Bind parameters to the prepared statement
    $stmt->bind_param("ssdss", $seller_id, $make, $picture, $price, $description);

    // Execute the prepared statement
    if ($stmt->execute() === TRUE) {
        echo "<script>alert('Added car!');</script>";
        echo "<script>window.location.href = 'add_car.php';</script>"; // Redirect to add_car.php
    } else {
        echo "<script>alert('Failed to Add car! Error: " . $conn->error . "');</script>";
        echo "<script>window.location.href = 'add_car.php';</script>"; // Redirect to add_car.php
    }

    // Close prepared statement
    $stmt->close();
}
include("add_car.php");
// Close connection
$conn->close();
?>
