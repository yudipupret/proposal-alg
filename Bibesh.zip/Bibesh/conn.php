<?php
    $conn= new mysqli("localhost","root","","users");
?>