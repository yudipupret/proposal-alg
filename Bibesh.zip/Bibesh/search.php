<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Search</title>
    <link rel="icon" type="image/png" href="https://img.icons8.com/3d-fluency/188/1FB141/icons8-new-logo.png">
</head>
<body>
    <header>
        <div class="logo">NewEra Dealership</div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="search.html">Search</a></li>
                <li><a href="add_car.php">Add car</a></li>
                <li><a href="seller.php">My Profile</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="registration.html"><img src="https://img.icons8.com/fluency/48/add-user-male.png" alt="Icon" width="32" height="32" /></a></li>
                <li><a href="login.php"><img src="https://img.icons8.com/fluency/48/login-rounded-right.png" alt="Icon" width="32" height="32" /></a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <h1>Search</h1>
        <form action="search.php" method="GET" class="search-form">
            <input type="text" name="search" id="search" placeholder="Search...">
            <button type="submit">Search</button>
        </form>
        <div class="search-results" id="searchResults">
            <!-- Search results will be displayed here -->
            <?php
include('conn.php');
include('globvar.php');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if search query is provided
if(isset($_GET['search'])) {
    $search = $_GET['search'];

    // Prepare SQL statement
    $sql = "SELECT cars.*, seller.name as seller_name FROM cars INNER JOIN seller ON cars.seller_id = seller.username WHERE cars.make LIKE '%$search%' OR cars.description LIKE '%$search%'";
    
    // Execute SQL statement
    $result = $conn->query($sql);

    // Display search results
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<div>";
            echo "<h2>".$row['make']."</h2>";
            // Display image if available
            if (!empty($row['picture'])) {
                echo "<img src='data:image/jpeg;base64,".base64_encode($row['picture'])."' alt='Car Picture'>";
            } else {
                echo "<p>No image available</p>";
            }
            echo "<p>Description: ".$row['description']."</p>";
            echo "<p>Price: ".$row['price']."</p>";
            echo "<p>Seller: ".$row['seller_name']."</p>";
            echo "</div>";
        }
    } else {
        echo "No results found.";
    }

    // Free result set
    $result->free_result();
} else {
    echo "No search query provided.";
}

// Close connection
$conn->close();
            
            ?>
        </div>
    </main>    
    
    <footer>
        <p>Contact us: info@neweradealership.com | Phone: +61-451681548</p>
    </footer>
    
    <script src="script.js"></script>
</body>
</html>
