<!DOCTYPE html>
<html lang="en">
<head>
<?php 
        include('globvar.php');
        include("seschk.php");
?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Add Car</title>
    <link rel="icon" type="image/png" href="https://img.icons8.com/3d-fluency/188/1FB141/icons8-new-logo.png">
</head>
<body>
    <header>
        <div class="logo">NewEra Dealership</div>
        <nav>
            <ul>

                <li><a href="search.html">Search</a></li>
                <li><a href="seller.php">My Profile</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <h1>Add Car</h1>
        <form id="carForm" action="add.php" method="POST" enctype="multipart/form-data">
        <label for="make">Make:</label>
        <input type="text" id="make" name="make" required>
        
        <label for="picture">Picture:</label>
        <input type="file" id="picture" name="picture" accept="image/*" required>
        
        <label for="price">Price:</label>
        <input type="number" id="price" name="price" required>
        
        <label for="description">Description:</label>
        <textarea id="description" name="description" rows="4" required></textarea>
        
        <button type="submit">Add Car</button>
    </form>
    </main>
    
    <footer>
        <p>Contact us: info@neweradealership.com | Phone: +61-451681548</p>
    </footer>
    
    <script src="script.js"></script>
    <script>  
        document.getElementById('carForm').addEventListener('submit', function(event) {
            const make = document.getElementById('make').value;
            const picture = document.getElementById('picture').value;
            const price = document.getElementById('price').value;
            const description = document.getElementById('description').value;
            
            if (!make || !picture || !price || !description) {
                event.preventDefault();
                alert('All fields are required.');
            }
        });</script>
</body>
</html>
