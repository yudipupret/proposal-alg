<?php
    include('conn.php');
    $isok=false;
    $existence=false;
    $name= $_POST["name"];
    $address= $_POST["address"];
    $phone_number=$_POST["phone"];
    $Email= $_POST["email"];
    $e= $_POST["user"];
    $p= $_POST["pass"];
    echo ('<script>console.log ("connecting to database")</script>');
    if($conn->connect_error)
    {
        echo ('<script>console.log ("database connection failed")</script>');
    }
    else{
        echo ('<script>console.log ("database connection success")</script>');
    }
    
    $query = "SELECT * FROM seller WHERE Username = '$e'";

    $result = $conn->query($query);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            $existence=true;
        } 
        else {
            $existence=false;
        }
    }

if($existence==false){  
  
        $sql="insert into seller(name,address,phone,email,username,password) values(?,?,?,?,?,?)";
         $stmt=$conn->prepare($sql);
        $stmt->bind_param('ssssss',$name,$address,$phone_number,$Email,$e,$p);
        
              
        if ($stmt->execute()) {
            echo ('<script>console.log ("record creation success")</script>');
            $isok=true;
           } else {
            echo ('<script>console.log ("record creation failure")</script>');
            $isok=false;
    }
}
else
{   echo ('<script>console.log ("existence of primary keyed data")</script>');
    echo ('<script>alert("Username is already taken. Please use another Username")</script>');

    $isok=false;
}
$conn->close();
if($isok==true)
{
    echo ('<script>alert("Successfully registered. Please Login")</script>');
    include('login.php');
    
}
else{
    include('registration.html');
}
?>
